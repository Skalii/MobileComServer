create function union_tariffs_offers__delete_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE tariffs
  SET ids_offer = ids_offer - OLD.id_offer
  WHERE id_tariff = OLD.id_tariff;

  RETURN OLD;
END;
$$;
