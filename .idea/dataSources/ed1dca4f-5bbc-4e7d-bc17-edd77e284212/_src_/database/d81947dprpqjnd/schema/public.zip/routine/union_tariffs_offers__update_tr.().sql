create function union_tariffs_offers__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE tariffs
  SET ids_offer = ids_offer - OLD.id_offer
  WHERE id_tariff = OLD.id_tariff;

  UPDATE tariffs
  SET ids_offer = ids_offer + NEW.id_offer
  WHERE id_tariff = NEW.id_tariff;

  RETURN NEW;
END;
$$;
