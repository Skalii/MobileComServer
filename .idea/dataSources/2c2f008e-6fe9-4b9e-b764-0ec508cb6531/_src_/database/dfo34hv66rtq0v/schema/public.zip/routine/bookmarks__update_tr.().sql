create function bookmarks__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE profiles
  SET ids_bookmark = ids_bookmark - OLD.id_site
  WHERE id_profile = OLD.id_profile;

  UPDATE profiles
  SET ids_bookmark = ids_bookmark + NEW.id_site
  WHERE id_profile = NEW.id_profile;

  RETURN NEW;
END;
$$;
