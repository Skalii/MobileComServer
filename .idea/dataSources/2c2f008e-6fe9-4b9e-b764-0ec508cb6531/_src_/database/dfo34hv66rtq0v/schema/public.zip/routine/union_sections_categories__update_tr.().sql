create function union_sections_categories__update_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE sections
  SET ids_category = ids_category - OLD.id_category
  WHERE id_section = OLD.id_section;

  UPDATE sections
  SET ids_category = ids_category + NEW.id_category
  WHERE id_section = NEW.id_section;

  RETURN NEW;
END;
$$;
